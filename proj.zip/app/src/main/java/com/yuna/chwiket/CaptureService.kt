package com.yuna.chwiket

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * 화면 캡처(MediaProjection) + 떠다니는 조작창(오버레이).
 *
 * 핵심: 마커는 평소 '터치 통과'(FLAG_NOT_TOUCHABLE) 상태라 자동 탭이 크롬에 그대로 꽂힌다.
 *  - "조준 이동" ON → 마커가 터치를 받아 드래그로 이동 가능 (이 동안은 탭 불가)
 *  - "색 확인" → 마커를 잠깐 숨겨 좌석 본색을 읽음
 *  - "여기 탭" → (이동모드면 끄고) 마커 중심 좌표를 접근성으로 탭
 */
class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null

    private var wm: WindowManager? = null
    private var panel: View? = null
    private var marker: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var label: TextView? = null
    private var btnMove: Button? = null

    private var moveMode = false
    private val handler = Handler(Looper.getMainLooper())

    // 스캔 영역 / 제외 영역 (화면좌표, -1 = 미설정)
    private var scanX1 = -1; private var scanY1 = -1; private var scanX2 = -1; private var scanY2 = -1
    private var exX1 = -1;   private var exY1 = -1;   private var exX2 = -1;   private var exY2 = -1

    private var screenW = 0
    private var screenH = 0
    private var densityDpi = 0
    private val markerSize = 40

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("data")
        if (code == Activity.RESULT_OK && data != null) {
            try {
                setupProjection(code, data)
            } catch (e: Exception) {
                toast("화면 읽기 준비 실패: " + e.message)
            }
        }
        try {
            showOverlay()
        } catch (e: Exception) {
            toast("오버레이 실패(권한 확인): " + e.message)
        }
        instance = this
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val chId = "capture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(chId, "화면읽기", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val noti: Notification =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, chId)
                    .setContentTitle("취켓팅테스트 실행 중")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .build()
            } else {
                Notification.Builder(this)
                    .setContentTitle("취켓팅테스트 실행 중")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .build()
            }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, noti, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, noti)
        }
    }

    private fun setupProjection(code: Int, data: Intent) {
        val metrics = resources.displayMetrics
        screenW = metrics.widthPixels
        screenH = metrics.heightPixels
        densityDpi = metrics.densityDpi
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {}
        }, null)
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "cap",
            screenW, screenH, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )
    }

    /** 화면 절대좌표 (x,y)의 색을 ARGB Int 로 읽는다. 못 읽으면 null. */
    fun readColorAt(x: Int, y: Int): Int? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val px = x.coerceIn(0, image.width - 1)
            val py = y.coerceIn(0, image.height - 1)
            val offset = py * rowStride + px * pixelStride
            val r = buffer.get(offset).toInt() and 0xFF
            val g = buffer.get(offset + 1).toInt() and 0xFF
            val b = buffer.get(offset + 2).toInt() and 0xFF
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        } catch (e: Exception) {
            return null
        } finally {
            image.close()
        }
    }

    private fun matchTarget(r: Int, g: Int, b: Int): Boolean {
        for (t in TARGETS) {
            if (kotlin.math.abs(r - t.first) <= COLOR_TOL &&
                kotlin.math.abs(g - t.second) <= COLOR_TOL &&
                kotlin.math.abs(b - t.third) <= COLOR_TOL
            ) return true
        }
        return false
    }

    /**
     * 화면에서 목표색(포도) 덩어리들을 찾아 '최상단(앞열)-최좌측' 덩어리의
     * 중심 화면좌표를 반환. 없으면 null.
     */
    fun findBestSeatScreenXY(): Pair<Int, Int>? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val pxStride = plane.pixelStride
            val rowStride = plane.rowStride
            val w = image.width
            val h = image.height
            val step = SCAN_STEP
            val gw = w / step
            val gh = h / step
            if (gw <= 0 || gh <= 0) return null

            // 스캔 영역 결정 (미설정이면 화면 전체)
            val hasScan = scanX1 >= 0 && scanY1 >= 0 && scanX2 >= 0 && scanY2 >= 0
            val sxMin = (if (hasScan) minOf(scanX1, scanX2) else 0).coerceIn(0, w - 1)
            val sxMax = (if (hasScan) maxOf(scanX1, scanX2) else w - 1).coerceIn(0, w - 1)
            val syMin = (if (hasScan) minOf(scanY1, scanY2) else 0).coerceIn(0, h - 1)
            val syMax = (if (hasScan) maxOf(scanY1, scanY2) else h - 1).coerceIn(0, h - 1)
            // 제외 영역
            val hasEx = exX1 >= 0 && exY1 >= 0 && exX2 >= 0 && exY2 >= 0
            val exMinX = if (hasEx) minOf(exX1, exX2) else 0
            val exMaxX = if (hasEx) maxOf(exX1, exX2) else -1
            val exMinY = if (hasEx) minOf(exY1, exY2) else 0
            val exMaxY = if (hasEx) maxOf(exY1, exY2) else -1

            val mask = BooleanArray(gw * gh)
            val gxStart = (sxMin / step).coerceIn(0, gw - 1)
            val gxEnd = (sxMax / step).coerceIn(0, gw - 1)
            val gyStart = (syMin / step).coerceIn(0, gh - 1)
            val gyEnd = (syMax / step).coerceIn(0, gh - 1)
            var gy = gyStart
            while (gy <= gyEnd) {
                val py = gy * step
                val rowBase = py * rowStride
                var gx = gxStart
                while (gx <= gxEnd) {
                    val px = gx * step
                    val inExclude = hasEx && px >= exMinX && px <= exMaxX && py >= exMinY && py <= exMaxY
                    if (!inExclude) {
                        val off = rowBase + px * pxStride
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        if (matchTarget(r, g, b)) mask[gy * gw + gx] = true
                    }
                    gx++
                }
                gy++
            }

            // 연결요소(BFS, 8방향)
            val visited = BooleanArray(gw * gh)
            val stack = IntArray(gw * gh)
            var bestCx = -1
            var bestCy = -1
            var i = 0
            while (i < gw * gh) {
                if (mask[i] && !visited[i]) {
                    var sp = 0
                    stack[sp++] = i
                    visited[i] = true
                    var sumX = 0L
                    var sumY = 0L
                    var cnt = 0
                    while (sp > 0) {
                        val cur = stack[--sp]
                        val cxg = cur % gw
                        val cyg = cur / gw
                        sumX += cxg; sumY += cyg; cnt++
                        var dy = -1
                        while (dy <= 1) {
                            var dx = -1
                            while (dx <= 1) {
                                if (dx != 0 || dy != 0) {
                                    val nx = cxg + dx
                                    val ny = cyg + dy
                                    if (nx in 0 until gw && ny in 0 until gh) {
                                        val ni = ny * gw + nx
                                        if (mask[ni] && !visited[ni]) {
                                            visited[ni] = true
                                            stack[sp++] = ni
                                        }
                                    }
                                }
                                dx++
                            }
                            dy++
                        }
                    }
                    if (cnt >= MIN_CELLS) {
                        val ccx = (sumX / cnt).toInt()
                        val ccy = (sumY / cnt).toInt()
                        if (bestCy == -1 || ccy < bestCy || (ccy == bestCy && ccx < bestCx)) {
                            bestCy = ccy
                            bestCx = ccx
                        }
                    }
                }
                i++
            }
            if (bestCy == -1) return null
            return Pair(bestCx * step, bestCy * step)
        } catch (e: Exception) {
            return null
        } finally {
            image.close()
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

    private fun markerCenter(): Pair<Int, Int> {
        val cx = markerParams!!.x + markerSize / 2
        val cy = markerParams!!.y + markerSize / 2
        return Pair(cx, cy)
    }

    private fun setMarkerTouchable(touchable: Boolean) {
        val p = markerParams ?: return
        p.flags = if (touchable)
            MARKER_BASE_FLAGS
        else
            MARKER_BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm?.updateViewLayout(marker, p) } catch (_: Exception) {}
    }

    private fun showOverlay() {
        if (panel != null) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // ── 조작 패널 ──
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(18, 18, 18, 18)
        }
        label = TextView(this).apply {
            text = "색: -"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
        }
        val btnCollapse = Button(this).apply { text = "▲ 창 접기" }
        val btnAuto = Button(this).apply { text = "🎯 자동 탐색+탭" }
        val btnColor = Button(this).apply { text = "색 확인" }
        val btnTap = Button(this).apply { text = "여기 탭" }
        val btnCenter = Button(this).apply { text = "조준 중앙" }
        btnMove = Button(this).apply { text = "조준 이동: 꺼짐" }
        // ── 영역 설정 버튼들 ──
        val btnScan1 = Button(this).apply { text = "스캔①좌상" }
        val btnScan2 = Button(this).apply { text = "스캔②우하" }
        val btnEx1 = Button(this).apply { text = "제외①좌상" }
        val btnEx2 = Button(this).apply { text = "제외②우하" }
        val btnClear = Button(this).apply { text = "영역 지우기" }

        fun rowOf(vararg bs: Button): LinearLayout {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (b in bs) row.addView(b)
            return row
        }

        // 접히는 본문(창 접기 하면 이 부분만 숨어서 창이 작아짐)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label)
        content.addView(btnAuto)
        content.addView(rowOf(btnColor, btnTap))
        content.addView(rowOf(btnCenter, btnMove))
        content.addView(rowOf(btnScan1, btnScan2))
        content.addView(rowOf(btnEx1, btnEx2))
        content.addView(btnClear)

        box.addView(btnCollapse)
        box.addView(content)

        btnCollapse.setOnClickListener {
            val hide = content.visibility != View.GONE
            content.visibility = if (hide) View.GONE else View.VISIBLE
            btnCollapse.text = if (hide) "▼ 창 펴기" else "▲ 창 접기"
        }
        btnCenter.setOnClickListener {
            val sw = if (screenW > 0) screenW else 1000
            val sh = if (screenH > 0) screenH else 2000
            markerParams?.x = sw / 2 - markerSize / 2
            markerParams?.y = sh / 2 - markerSize / 2
            try { wm?.updateViewLayout(marker, markerParams) } catch (_: Exception) {}
            label?.text = "조준 중앙으로"
        }

        btnScan1.setOnClickListener {
            val (cx, cy) = markerCenter(); scanX1 = cx; scanY1 = cy
            label?.text = "스캔①=($cx,$cy)"
        }
        btnScan2.setOnClickListener {
            val (cx, cy) = markerCenter(); scanX2 = cx; scanY2 = cy
            label?.text = "스캔②=($cx,$cy)"
        }
        btnEx1.setOnClickListener {
            val (cx, cy) = markerCenter(); exX1 = cx; exY1 = cy
            label?.text = "제외①=($cx,$cy)"
        }
        btnEx2.setOnClickListener {
            val (cx, cy) = markerCenter(); exX2 = cx; exY2 = cy
            label?.text = "제외②=($cx,$cy)"
        }
        btnClear.setOnClickListener {
            scanX1 = -1; scanY1 = -1; scanX2 = -1; scanY2 = -1
            exX1 = -1; exY1 = -1; exX2 = -1; exY2 = -1
            label?.text = "영역 초기화됨(전체 스캔)"
        }

        val boxParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 120
        }

        // ── 마커(조준점) : 평소엔 터치 통과 ──
        marker = View(this).apply { setBackgroundColor(0xBBFF2222.toInt()) }
        markerParams = WindowManager.LayoutParams(
            markerSize, markerSize,
            overlayType(),
            MARKER_BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (if (screenW > 0) screenW / 2 else 300)
            y = 700
        }

        btnAuto.setOnClickListener {
            if (moveMode) setMoveMode(false)
            // 오버레이가 캡처에 섞이지 않도록 잠깐 숨김
            marker?.visibility = View.INVISIBLE
            panel?.visibility = View.INVISIBLE
            handler.postDelayed({
                val xy = findBestSeatScreenXY()
                if (xy == null) {
                    panel?.visibility = View.VISIBLE
                    marker?.visibility = View.VISIBLE
                    label?.text = "포도 못 찾음"
                } else {
                    // 찾은 자리로 마커를 옮겨 보여주고 탭 (패널은 탭에 안 걸리게 뒤에 복귀)
                    markerParams?.x = xy.first - markerSize / 2
                    markerParams?.y = xy.second - markerSize / 2
                    try { wm?.updateViewLayout(marker, markerParams) } catch (_: Exception) {}
                    marker?.visibility = View.VISIBLE
                    label?.text = String.format("포도 발견→탭 (%d,%d)", xy.first, xy.second)
                    TapService.instance?.tap(xy.first, xy.second)
                    handler.postDelayed({ panel?.visibility = View.VISIBLE }, 220)
                }
            }, 220)
        }

        btnColor.setOnClickListener {
            // 마커를 잠깐 숨겨 좌석 본색을 읽는다
            marker?.visibility = View.INVISIBLE
            handler.postDelayed({
                val (cx, cy) = markerCenter()
                val c = readColorAt(cx, cy)
                label?.text = if (c == null)
                    "색: 못읽음 (화면읽기 시작했나요?)"
                else
                    String.format("색: #%06X  (%d,%d)", c and 0xFFFFFF, cx, cy)
                marker?.visibility = View.VISIBLE
            }, 160)
        }

        btnTap.setOnClickListener {
            // 이동모드면 먼저 끄고(마커 터치통과로) 잠시 뒤 탭 → 크롬에 꽂히게
            if (moveMode) setMoveMode(false)
            handler.postDelayed({
                val (cx, cy) = markerCenter()
                val t = TapService.instance
                if (t == null) {
                    toast("접근성(탭)이 꺼져 있어요")
                } else {
                    t.tap(cx, cy)
                    toast("탭! ($cx,$cy)")
                }
            }, 70)
        }

        btnMove!!.setOnClickListener {
            setMoveMode(!moveMode)
        }

        // 마커 드래그(이동모드에서만 터치가 들어옴)
        marker!!.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = markerParams!!.x
                        startY = markerParams!!.y
                        touchX = e.rawX
                        touchY = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        markerParams!!.x = startX + (e.rawX - touchX).toInt()
                        markerParams!!.y = startY + (e.rawY - touchY).toInt()
                        try { wm!!.updateViewLayout(marker, markerParams) } catch (_: Exception) {}
                    }
                }
                return true
            }
        })

        // 창을 먼저, 마커를 나중에 → 마커가 항상 창 위에 있어 창 뒤로 숨지 않음
        wm!!.addView(box, boxParams)
        wm!!.addView(marker, markerParams)
        panel = box
    }

    private fun setMoveMode(on: Boolean) {
        moveMode = on
        setMarkerTouchable(on)
        marker?.setBackgroundColor(if (on) 0xCC22CC22.toInt() else 0xBBFF2222.toInt())
        btnMove?.text = if (on) "조준 이동: 켜짐(드래그)" else "조준 이동: 꺼짐"
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        try { marker?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: CaptureService? = null

        // 오버레이를 '화면 전체 기준'으로 두어 마커 위치 = 실제 탭/캡처 좌표가 되게 한다
        private val MARKER_BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        // 목표 색(빈자리). 팔린자리 #EDEFF3 는 제외.
        private val TARGETS = listOf(
            Triple(0xD1, 0xCA, 0xF9),  // 보라
            Triple(0x1C, 0xA8, 0x14)   // 초록
        )
        private const val COLOR_TOL = 22   // 채널별 허용 오차
        private const val SCAN_STEP = 4    // 몇 픽셀 간격으로 스캔(속도)
        private const val MIN_CELLS = 5    // 이보다 작은 덩어리는 노이즈로 무시
    }
}
