package com.yuna.chwiket

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * 화면 캡처(MediaProjection) + 떠다니는 조작창(오버레이).
 *
 * 핵심: 마커는 평소 '터치 통과'(FLAG_NOT_TOUCHABLE) 상태라 자동 탭이 크롬에 그대로 꽂힌다.
 *  - "조준 이동" ON → 마커가 터치를 받아 드래그로 이동 가능 (이 동안은 탭 불가)
 *  - "색 확인" → 마커를 잠깐 숨겨 좌석 본색을 읽음
 *  - "여기 탭" → (이동모드면 끄고) 마커 중심 좌표를 접근성으로 탭
 */
class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null

    private var wm: WindowManager? = null
    private var panel: View? = null
    private var marker: View? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var label: TextView? = null
    private var btnMove: Button? = null

    private var moveMode = false
    private val handler = Handler(Looper.getMainLooper())

    private var screenW = 0
    private var screenH = 0
    private var densityDpi = 0
    private val markerSize = 40

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("data")
        if (code == Activity.RESULT_OK && data != null) {
            try {
                setupProjection(code, data)
            } catch (e: Exception) {
                toast("화면 읽기 준비 실패: " + e.message)
            }
        }
        try {
            showOverlay()
        } catch (e: Exception) {
            toast("오버레이 실패(권한 확인): " + e.message)
        }
        instance = this
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val chId = "capture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(chId, "화면읽기", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val noti: Notification =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, chId)
                    .setContentTitle("취켓팅테스트 실행 중")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .build()
            } else {
                Notification.Builder(this)
                    .setContentTitle("취켓팅테스트 실행 중")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .build()
            }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, noti, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, noti)
        }
    }

    private fun setupProjection(code: Int, data: Intent) {
        val metrics = resources.displayMetrics
        screenW = metrics.widthPixels
        screenH = metrics.heightPixels
        densityDpi = metrics.densityDpi
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {}
        }, null)
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "cap",
            screenW, screenH, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )
    }

    /** 화면 절대좌표 (x,y)의 색을 ARGB Int 로 읽는다. 못 읽으면 null. */
    fun readColorAt(x: Int, y: Int): Int? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val px = x.coerceIn(0, image.width - 1)
            val py = y.coerceIn(0, image.height - 1)
            val offset = py * rowStride + px * pixelStride
            val r = buffer.get(offset).toInt() and 0xFF
            val g = buffer.get(offset + 1).toInt() and 0xFF
            val b = buffer.get(offset + 2).toInt() and 0xFF
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        } catch (e: Exception) {
            return null
        } finally {
            image.close()
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

    private fun markerCenter(): Pair<Int, Int> {
        val cx = markerParams!!.x + markerSize / 2
        val cy = markerParams!!.y + markerSize / 2
        return Pair(cx, cy)
    }

    private fun setMarkerTouchable(touchable: Boolean) {
        val p = markerParams ?: return
        p.flags = if (touchable)
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm?.updateViewLayout(marker, p) } catch (_: Exception) {}
    }

    private fun showOverlay() {
        if (panel != null) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // ── 조작 패널 ──
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(18, 18, 18, 18)
        }
        label = TextView(this).apply {
            text = "색: -"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
        }
        val btnColor = Button(this).apply { text = "색 확인" }
        val btnTap = Button(this).apply { text = "여기 탭" }
        btnMove = Button(this).apply { text = "조준 이동: 꺼짐" }
        box.addView(label)
        box.addView(btnColor)
        box.addView(btnTap)
        box.addView(btnMove)

        val boxParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 120
        }

        // ── 마커(조준점) : 평소엔 터치 통과 ──
        marker = View(this).apply { setBackgroundColor(0xBBFF2222.toInt()) }
        markerParams = WindowManager.LayoutParams(
            markerSize, markerSize,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (if (screenW > 0) screenW / 2 else 300)
            y = 700
        }

        btnColor.setOnClickListener {
            // 마커를 잠깐 숨겨 좌석 본색을 읽는다
            marker?.visibility = View.INVISIBLE
            handler.postDelayed({
                val (cx, cy) = markerCenter()
                val c = readColorAt(cx, cy)
                label?.text = if (c == null)
                    "색: 못읽음 (화면읽기 시작했나요?)"
                else
                    String.format("색: #%06X  (%d,%d)", c and 0xFFFFFF, cx, cy)
                marker?.visibility = View.VISIBLE
            }, 160)
        }

        btnTap.setOnClickListener {
            // 이동모드면 먼저 끄고(마커 터치통과로) 잠시 뒤 탭 → 크롬에 꽂히게
            if (moveMode) setMoveMode(false)
            handler.postDelayed({
                val (cx, cy) = markerCenter()
                val t = TapService.instance
                if (t == null) {
                    toast("접근성(탭)이 꺼져 있어요")
                } else {
                    t.tap(cx, cy)
                    toast("탭! ($cx,$cy)")
                }
            }, 70)
        }

        btnMove!!.setOnClickListener {
            setMoveMode(!moveMode)
        }

        // 마커 드래그(이동모드에서만 터치가 들어옴)
        marker!!.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = markerParams!!.x
                        startY = markerParams!!.y
                        touchX = e.rawX
                        touchY = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        markerParams!!.x = startX + (e.rawX - touchX).toInt()
                        markerParams!!.y = startY + (e.rawY - touchY).toInt()
                        try { wm!!.updateViewLayout(marker, markerParams) } catch (_: Exception) {}
                    }
                }
                return true
            }
        })

        wm!!.addView(marker, markerParams)
        wm!!.addView(box, boxParams)
        panel = box
    }

    private fun setMoveMode(on: Boolean) {
        moveMode = on
        setMarkerTouchable(on)
        marker?.setBackgroundColor(if (on) 0xCC22CC22.toInt() else 0xBBFF2222.toInt())
        btnMove?.text = if (on) "조준 이동: 켜짐(드래그)" else "조준 이동: 꺼짐"
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        try { marker?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: CaptureService? = null
    }
}
